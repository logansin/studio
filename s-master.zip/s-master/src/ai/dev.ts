
import { config } from 'dotenv';
config();

import '@/ai/flows/generate-anime-recommendations.ts';
import '@/ai/flows/generateRandomAnime.ts';

    